// Library Declaration

#include <iostream>
#include <fstream> 
#include <string>
#include <vector>
#include <numeric>
#include "stdio.h"

// Name Space Declaration

using namespace std;


//Variable Declaration
string fileName;
vector <int> tempVec;				
vector<vector<int> > stored2DVector;		
int numOfFiles;						
int keepTemp(string data);			
void readFile(int fileNumber);		
int fileCount();										
int findMaxRow(int fileNumber);			
void calculationModule(int input);

//Main Function with the supporting functions

int main() 
{
	fileCount(); // count number of file
	readFile(numOfFiles); // read the corresponding files
	int maxLineNumber = findMaxRow(numOfFiles) - 1; //Get the corresponding max line number to determine the time
	calculationModule(maxLineNumber); // calculate the corresponding data point and average point
	system("pause");// Hold the console for the user interface
};



//return the max number of rows contained in the file, which is used for determining the combined time

int findMaxRow(int count)
{
	//Variable Declarization
	vector<int> numberOfRows;
	string b;
	//File Read
	for (int i = 0; i < count; i++)
	{
		//Start with 1
		int temp = i + 1; 
		//String combination
		b = "Experiment" + to_string(temp) + ".csv";
		//variable initization
		int rows = 0;
		ifstream file(b);
		string line;
		//read the corresponding rows
		while (getline(file, line))
			rows++;
		//push back corresponding row to the number of rows vector
		numberOfRows.push_back(rows);
	}
	//Max Value Determination
	int max = 0;
	//return the max value
	for (int i = 0; i < count; i++)
	{
		if (max < numberOfRows[i])
		{
			max = numberOfRows[i];
		}
	}
	return max;
}

//Find the corresponding files contained within the file

int fileCount()
{
	//for loop
	for (int i = 1;; i++)
	{
		//generate the corresponding fileName
		fileName = "Experiment" + to_string(i) + ".csv";
		//if the file is open
		ifstream myfile(fileName);
		if (myfile.is_open())
		{
			//increase the number of files by one
			numOfFiles++;
			//close myfile
			myfile.close();
		}
		else
		{
			//close myfile
			myfile.close();
			return numOfFiles;
		}
	}
	//return the number of files
	return numOfFiles;
}

// read file function
void readFile(int fileNumber)
{
	
	for (int i = 0; i <= fileNumber; i++)
	{
		//variable initizalization
		string headLine;
		string data;
		ifstream myfile(fileName);
		//generate the corresponding file name
		fileName = "Experiment" + to_string(i + 1) + ".csv";
		//read the headline of the file
		getline(myfile, headLine);
		//if there myfile is not empty
		while (myfile)
		{
			//continuing reading the file
			getline(myfile, data);
			//keep only the valided data 
			int temp = keepTemp(data);
			//push the valid data to the vector
			tempVec.push_back(temp);
		}
		//push the vector back
		stored2DVector.push_back(tempVec);
		//clear the vector
		tempVec.clear();
	}
	//initialization
	for (int i = 1; i <= fileNumber; i++)
	{
		//set the column
		int column = stored2DVector[i].capacity();
		//initialize the first row and column
		stored2DVector[i][column - 1] = 0;
	}

}

// Function to only only extract the temperature 
int keepTemp(string input)
{
	//examine the input
	while (input != "")
	{
		//find delimiter
		int delimiter = input.find(",");
		//find the pure temperature
		string leftString = input.erase(0, delimiter + 1);

		//cout << leftString << "!!!!!!!!!!!!!";

		int output = stod(leftString);
		//return the corresponding output
		return output;
	}
}

void calculationModule(int input)
{
	//Generatet the corresponding output file
	ofstream newfile("output.csv");
	//Set the corresponding column name
	newfile << "Recorded Times,Averaged Temperature,Measured DataPoints" << '\n';
	//store it to the two dimension vector
	for (int i = 0; i < input; i++)
	{
		//variable ini
		double mean;
		int summation = 0;
		double measuredPoint = 0;
		//store it to the one dimension vector
		for (int j = 1; j <= numOfFiles; j++)
		{
			if (i + 1 < stored2DVector[j].size())
			{
				//Add the corresponding summation
				summation += stored2DVector[j][i];
				//increase the measued data point by one
				measuredPoint += 1;
			}
		}
		//calcultating of the mean
		mean = summation / measuredPoint;
		//output the information to the file
		newfile << 0.1 * i << "," << to_string(mean) << "," << to_string(measuredPoint) << '\n';
		//print to the console for the debug purposes
		cout << mean << "|" << measuredPoint << '\n';
	}
}




